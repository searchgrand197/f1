# project/urls.py
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from dashboard.views import CustomerSearchCreateView,ShareItemView,AuthenticatedCheckView,AdminInsightsAPIView,ItemSearchView,KeywordCreateView,upload_data_folder,search_items,item_search_page,create_affiliate_user,secure_change_affiliate_status,AffiliateLoginView,add_comment,reply_to_comment,AffiliateLinkViewSet,initiate_payment
from django.urls import path, re_path
from dashboard.views import ReactAppView,fetch_pin_code,fetch_delivery_charges,createshipment , refund_payment , send_cancellation_sms,send_order_sms, get_orders_by_user_id
urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/check-authenticated/', AuthenticatedCheckView.as_view(), name='check-authenticated'),
    path('api/share/<str:unique_code>/', ShareItemView.as_view(), name='share-item'),
    path('api/', include('dashboard.urls')),
    path('insights/', AdminInsightsAPIView.as_view(), name='admin-insights'),
    path('items/search/', ItemSearchView.as_view(), name='item-search'),
    path('keywords/', KeywordCreateView.as_view(), name='keyword-create'),
    path('upload/', upload_data_folder, name='upload_data_folder'),
    path('search2/', search_items, name='search_items'),
    path('search/', item_search_page, name='item_search_page'),
    path('affiliate/create/', create_affiliate_user, name='create_affiliate_user'),
    path('affiliate/status/<str:token>/', secure_change_affiliate_status, name='secure_change_affiliate_status'),
    path('api/affiliate/login/', AffiliateLoginView.as_view(), name='affiliate-login'),
    path('items/<int:item_id>/comments/', add_comment, name='add-comment'),
    path('comments/<int:comment_id>/reply/', reply_to_comment, name='reply-to-comment'),
    path('affiliate/<str:username>/links/', AffiliateLinkViewSet.as_view({'get': 'get_affiliate_links'})),
    path('initiate-payment/', initiate_payment, name='initiate_payment'),
    path('api/customer-search-create/', CustomerSearchCreateView.as_view(), name='customer-search-create'),
    path('fetch-pin-code/', fetch_pin_code, name='fetch-pin-code'),
    path('fetch-delivery-charges/', fetch_delivery_charges, name='fetch_delivery_charges'),
    path('cs/', createshipment, name='createshipment'),
    path('refund/', refund_payment, name='refund_payment'),
    path('cancel-sms/', send_cancellation_sms, name='cancel_sms'),
    path('order-sms/', send_order_sms, name='order_sms'),
    path('api/orders/user/<str:user_id>/', get_orders_by_user_id, name='orders-by-user'),
    re_path(r'^.*$', ReactAppView.as_view(), name='react-app'),
    
    

    # Include the URLs from the app

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
