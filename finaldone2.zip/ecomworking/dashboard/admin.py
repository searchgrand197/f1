from django.contrib import admin
from .models import Category, Subcategory, Keyword, Item, Affiliate, AffiliateLink, Order,ItemVariant,AffiliateLogin, OrderDashboard, OrderDashboardItem

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'discount']
    search_fields = ['name']

@admin.register(Subcategory)
class SubcategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'category', 'discount']
    search_fields = ['name', 'category__name']

@admin.register(Keyword)
class KeywordAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']

class ItemVariantInline(admin.TabularInline):
    model = ItemVariant
    extra = 1


admin.site.register(ItemVariant)
@admin.register(Affiliate)
class AffiliateAdmin(admin.ModelAdmin):
    list_display = ['user', 'points']
    search_fields = ['user__username']

@admin.register(AffiliateLink)
class AffiliateLinkAdmin(admin.ModelAdmin):
    list_display = ['affiliate', 'item', 'unique_code', 'created_at']
    search_fields = ['affiliate__user__username', 'item__name', 'unique_code']

from django.contrib import admin
from .models import Advertisement

from django.contrib import admin
from .models import Advertisement, AdvertisementImage

# Inline admin for AdvertisementImage
class AdvertisementImageInline(admin.TabularInline):
    model = AdvertisementImage
    extra = 1  # Number of extra empty image slots in the form

# Admin class for Advertisement
@admin.register(Advertisement)
class AdvertisementAdmin(admin.ModelAdmin):
    list_display = ('id', 'sliding_text')  # Fields to display in the list view
    search_fields = ('sliding_text',)  # Enable search by sliding text
    inlines = [AdvertisementImageInline]  # Add the inline for landscape images
    filter_horizontal = ('handpicked_items',)  # Show a horizontal filter widget for handpicked items

# Optionally register AdvertisementImage (only if you want to manage images separately)
@admin.register(AdvertisementImage)
class AdvertisementImageAdmin(admin.ModelAdmin):
    list_display = ('advertisement', 'image')  # Display the advertisement and image fields
    search_fields = ('advertisement__sliding_text',)  # Enable search by advertisement sliding text

from django.contrib import admin
from .models import AffiliateUser

@admin.register(AffiliateUser)
class AffiliateUserAdmin(admin.ModelAdmin):
    list_display = ('uid', 'name', 'mobile', 'age', 'affiliate_status')

@admin.register(AffiliateLogin)
class AffiliateUserAdmin(admin.ModelAdmin):
    list_display = ( 'username', 'password')

from django.contrib import admin
from .models import Comment, Reply

# Inline for showing replies under the related comment
class ReplyInline(admin.TabularInline):
    model = Reply
    extra = 1  # Number of extra reply forms to display (can be 0 if you don't want extra)

# Admin class for managing comments
class CommentAdmin(admin.ModelAdmin):
    list_display = ('user', 'item', 'content', 'created_at')  # Fields to display in the admin list view
    search_fields = ('content', 'user__username', 'item__name')  # Add search functionality by user, item, or content
    list_filter = ('created_at', 'user')  # Filters on the right panel by created time and user
    inlines = [ReplyInline]  # Add inline replies under comments

admin.site.register(Comment, CommentAdmin)

# Fix the ReplyAdmin by using the correct field names
class ReplyAdmin(admin.ModelAdmin):
    list_display = ('comment', 'content', 'created_at')  # Correctly reference fields that exist in the model
    search_fields = ('content', 'comment__content')  # Search by content of reply or related comment

admin.site.register(Reply, ReplyAdmin)


from django.contrib import admin
from .models import Order, OrderItem, Item, Coupon

class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 1

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'delivery_status', 'get_subtotal', 'coupon', 'get_total_price', 'created_at')
    inlines = [OrderItemInline]

    def get_total_price(self, obj):
        return obj.get_total_price()
    get_total_price.short_description = 'Grand Total'

    def get_subtotal(self, obj):
        return obj.get_subtotal()
    get_subtotal.short_description = 'Subtotal'

@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'sku', 'price', 'stock')  # Customize fields as needed
    search_fields = ('name', 'sku')  # Required for autocomplete_fields
    list_filter = ('subcategory', 'stock')
    ordering = ('id',)

@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ('name', 'amount')
from django.contrib import admin
from .models import Customer, Address, CartItem, Item

class AddressInline(admin.TabularInline):
    model = Address
    extra = 1  # Allows adding extra addresses directly in the admin panel

class CartItemInline(admin.TabularInline):
    model = CartItem
    extra = 1  # Allows adding extra cart items directly in the admin panel

class CustomerAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'wallet_amount')
    search_fields = ('name', 'email', 'phone')
    list_filter = ('wallet_amount',)
    ordering = ('name',)
    inlines = [AddressInline, CartItemInline]  # Include addresses and cart items as inline forms

admin.site.register(Customer, CustomerAdmin)
from .models import PickupLocation, ReturnDetails

@admin.register(PickupLocation)
class PickupLocationAdmin(admin.ModelAdmin):
    list_display = ("name", "city", "state", "pin", "phone")

@admin.register(ReturnDetails)
class ReturnDetailsAdmin(admin.ModelAdmin):
    list_display = ("name", "city", "state", "pin", "phone")

from django.contrib import admin
from .models import AdvertisementNew
from django.contrib import admin
from django.core.exceptions import ValidationError
from django.contrib import messages
class AdvertisementAdmin1(admin.ModelAdmin):
    list_display = ('id', 'slideshow1', 'box1', 'big1', 'item_slideshow1')  # Fields to display in the list view
    list_filter = ('slideshow1', 'box1')  # Fields to enable filtering
    ordering = ('id',)  # Default ordering
    autocomplete_fields = ['item_slideshow1', 'item_box1', 'item_big1']  # Enable dropdown autocomplete for related fields
    readonly_fields = ('id',)  # Make the ID field read-only




    def save_model(self, request, obj, form, change):
        try:
            obj.save()
        except ValidationError as e:
            self.message_user(request, f"Error: {e.message}", level=messages.ERROR)

admin.site.register(AdvertisementNew, AdvertisementAdmin1)


class OrderDashboardItemInline(admin.TabularInline):
    model = OrderDashboardItem
    extra = 1

@admin.register(OrderDashboard)
class OrderDashboardAdmin(admin.ModelAdmin):
    list_display = ('name', 'mobile_number', 'total_amount', 'order_datetime', 'order_type', 'pay_id')
    list_filter = ('order_type', 'order_datetime')
    search_fields = ('name', 'mobile_number', 'pay_id')
    inlines = [OrderDashboardItemInline]

@admin.register(OrderDashboardItem)
class OrderDashboardItemAdmin(admin.ModelAdmin):
    list_display = ('order', 'name', 'price', 'sku', 'quantity')
    list_filter = ('order',)
    search_fields = ('name', 'sku')
