from django.db import models
from django.contrib.auth.models import User
from django.utils.crypto import get_random_string
# Create your models here.
from django.db import models
from django.utils.crypto import get_random_string
from django.contrib.auth.models import User  # Import the User model
from django.core.exceptions import ValidationError
from django.utils import timezone
import random
from django.db import models

class AffiliateUser(models.Model):
    STATUS_CHOICES = [
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('blocked', 'Blocked'),
        ('pending', 'Pending'),
    ]

    uid = models.CharField(max_length=6, unique=True, editable=False)
    name = models.CharField(max_length=100)
    mobile = models.CharField(max_length=15)
    email = models.EmailField(max_length=255)  # Add this line
    age = models.PositiveIntegerField()
    address = models.TextField()
    document_type = models.CharField(max_length=20)
    document_upload = models.FileField(upload_to='documents/')
    roa = models.CharField(max_length=100, default='None')  # ROA stands for Reason of Association or something similar
    affiliate_status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    link_generated_at = models.DateTimeField(default=timezone.now)  # Track when the link was generated
    link_expiry_duration = models.DurationField(default=timezone.timedelta(hours=24))  # 24-hour expiry

    def is_link_valid(self):
        """
        Check if the link is still valid based on the 24-hour expiration period.
        """
        expiration_time = self.link_generated_at + self.link_expiry_duration
        return timezone.now() < expiration_time
    def save(self, *args, **kwargs):
        if not self.uid:
            self.uid = ''.join(random.choices('0123456789', k=6))
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name

from django.contrib.auth.hashers import make_password, check_password
from django.db import models

class AffiliateLogin(models.Model):
    affiliate_user = models.OneToOneField(AffiliateUser, on_delete=models.CASCADE)
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=128)


    def check_password(self, raw_password):
        return check_password(raw_password, self.password)
class Category(models.Model):
    name = models.CharField(max_length=255,unique=True)
    image = models.ImageField(upload_to='category_images/',null=True, blank=True)
    details = models.TextField(null=True, blank=True)
    discount = models.DecimalField(default=0,max_digits=5, decimal_places=2)  # Discount in percentage

    def __str__(self):
        return self.name

class Subcategory(models.Model):
    name = models.CharField(max_length=255,unique=True)
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, related_name='subcategory')
    details = models.TextField(null=True, blank=True)
    image = models.ImageField(upload_to='subcategory_images/',null=True, blank=True)
    discount = models.DecimalField(default=0,max_digits=5, decimal_places=2)

    def __str__(self):
        return self.name

class Keyword(models.Model):
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.name
class Item(models.Model):
    name = models.CharField(max_length=255,unique=True)
    image1 = models.ImageField(upload_to='subcategory_images/', null=True, blank=True)
    image2 = models.ImageField(upload_to='subcategory_images/', null=True, blank=True)
    image3 = models.ImageField(upload_to='subcategory_images/', null=True, blank=True)
    video = models.FileField(upload_to='videos/', null=True, blank=True)  # Add this line
    subcategory = models.ForeignKey(Subcategory, on_delete=models.SET_NULL, null=True, blank=True, related_name='items')
    sku = models.CharField(max_length=100, unique=True)
    stock = models.PositiveIntegerField(default=1)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    discount = models.DecimalField(default=1,max_digits=5, decimal_places=2)  # Discount in percentage
    specification = models.TextField(null=True, blank=True)
    token = models.PositiveIntegerField(default=0)
    special_item_status = models.BooleanField(default=False)
    affiliate_token = models.PositiveIntegerField(default=10,null=True, blank=True)
    last_modified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)  # New field
    keywords = models.ManyToManyField(Keyword, related_name='items', blank=True)  # New field
    # New fields
    length = models.DecimalField(max_digits=10, decimal_places=2, default=0, help_text="Length in cm")
    breadth = models.DecimalField(max_digits=10, decimal_places=2, default=0, help_text="Breadth in cm")
    height = models.DecimalField(max_digits=10, decimal_places=2, default=0, help_text="Height in cm")
    weight = models.DecimalField(max_digits=10, decimal_places=2, default=100, help_text="Weight in grams")

    class Meta:
        ordering = ['name']
    def __str__(self):
        return self.name

class ItemVariant(models.Model):
    item = models.ForeignKey(Item, related_name='variants', on_delete=models.CASCADE)
    color = models.CharField(max_length=50, blank=True, null=True)
    size = models.CharField(max_length=50, blank=True, null=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField(default=0)

    def __str__(self):
        attributes = []
        if self.color:
            attributes.append(f"Color: {self.color}")
        if self.size:
            attributes.append(f"Size: {self.size}")
        return f"{self.item.name} - {' '.join(attributes)}"
class Affiliate(models.Model):
    user = models.OneToOneField(AffiliateLogin, on_delete=models.CASCADE)
    points = models.IntegerField(default=0)

    def __str__(self):
        return self.user.username
class AffiliateLink(models.Model):
    affiliate = models.ForeignKey(Affiliate, on_delete=models.CASCADE)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    unique_code = models.CharField(max_length=10, unique=True, default=get_random_string)
    affiliate_token = models.PositiveIntegerField(null=True,blank=True)  # New field to store the token from the item
    created_at = models.DateTimeField(default=timezone.now, editable=True)
    def save(self, *args, **kwargs):
        # Set token_amount to the token value from the associated Item before saving
        if not self.affiliate_token:
            self.affiliate_token = self.item.affiliate_token
        super().save(*args, **kwargs)

    def generate_link(self):
        return f"http://foodporium-env.eba-wnzyt2im.eu-north-1.elasticbeanstalk.com/api/share/{self.unique_code}/"



from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User

class Coupon(models.Model):
    name = models.CharField(max_length=50)
    amount = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.name} (-${self.amount})"


class Order(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    order_id = models.CharField(max_length=20,null=True)
    address = models.CharField(max_length=20,null=True)
    delivery_status = models.CharField(
        max_length=20,null=True,
        choices=[('pending', 'Pending'), ('dispatched', 'Dispatched'), ('cancelled', 'Cancelled')],
        default='pending'
    )
    payment_status = models.CharField(
        max_length=20,null=True,
        choices=[('successful', 'Successful'), ('failed', 'Failed'), ('pending', 'Pending')],
        default='pending'
    )
    coupon = models.ForeignKey(Coupon, null=True, blank=True, on_delete=models.SET_NULL)  # Optional coupon
    created_at = models.DateTimeField(default=timezone.now)
    region = models.CharField(max_length=100)

    def get_subtotal(self):
        # Sum the total price of all related order items (subtotal)
        return sum(order_item.get_total_item_price() for order_item in self.order_items.all())

    def get_total_price(self):
        # Get the subtotal and subtract the coupon amount (if applied) to get the grand total
        subtotal = self.get_subtotal()
        if self.coupon:
            discount = self.coupon.amount
        else:
            discount = 0
        grand_total = subtotal - discount
        return max(grand_total, 0)  # Ensure total is not negative

    def __str__(self):
        return f"Order {self.id} by {self.user.username} (Total Price: {self.get_total_price()})"

class OrderItem(models.Model):
    item = models.ForeignKey(Item, related_name="order_items", on_delete=models.CASCADE)
    order = models.ForeignKey(Order, related_name='order_items', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def get_total_item_price(self):
        # Calculate total price for this item (price * quantity)
        return self.quantity * self.price

    def __str__(self):
        return f"{self.item.name} (x{self.quantity})"

class Advertisement(models.Model):
    # Single sliding text
    sliding_text = models.TextField(null=True, blank=True)
    flash_image= models.ImageField(upload_to='advertisement_images/',null=True, blank=True)
    # Many-to-many relationship for handpicked items (unlimited)
    handpicked_items = models.ManyToManyField('Item', related_name='advertisements', blank=True)

    def __str__(self):
        return f"Advertisement {self.id}"


class AdvertisementImage(models.Model):
    # Each image belongs to an Advertisement
    advertisement = models.ForeignKey(Advertisement, related_name='landscape_images', on_delete=models.CASCADE)

    # Image field to store landscape images
    image = models.ImageField(upload_to='advertisement_images/')

    def __str__(self):
        return f"Image for Advertisement {self.advertisement.id}"


from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.utils import timezone

# Custom UserManager
class UserManager(BaseUserManager):
    def create_user(self, email, mobile_number, password=None):
        if not email:
            raise ValueError('Users must have an email address')
        if not mobile_number:
            raise ValueError('Users must have a mobile number')

        user = self.model(
            email=self.normalize_email(email),
            mobile_number=mobile_number,
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, mobile_number, password=None):
        user = self.create_user(
            email=email,
            mobile_number=mobile_number,
            password=password,
        )
        user.is_admin = True
        user.save(using=self._db)
        return user

# Custom User model
class User(AbstractBaseUser):
    name =  models.CharField(max_length=15,null=True)
    email = models.EmailField(max_length=255, unique=True)
    mobile_number = models.CharField(max_length=13, unique=True)
    wallet_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)  # Store the wallet amount

    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)

    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['mobile_number']

    def __str__(self):
        return self.email

    def get_full_name(self):
        return self.email

    def get_short_name(self):
        return self.email

    @property
    def is_staff(self):
        return self.is_admin


# Address model (can store multiple addresses per user)

from django.db import models
from django.contrib.auth.models import User


class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=255,blank=True)
    email = models.EmailField(max_length=255,blank=True)
    phone = models.CharField(max_length=15)
    wallet_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)

    def __str__(self):
        return self.name



# Intermediary model to store cart items with quantity
class CartItem(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='cart_items')
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='cart_items')
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        unique_together = ('customer', 'item')  # Ensures that a customer can't have the same item twice

    def __str__(self):
        return f"{self.item.name} (x{self.quantity}) - {self.customer.name}"
class WishItem(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='wishs_items')
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='wish_items')
    quantity = models.PositiveIntegerField(default=1)

    class Meta:
        unique_together = ('customer', 'item')  # Ensures that a customer can't have the same item twice

    def __str__(self):
        return f"{self.item.name} (x{self.quantity}) - {self.customer.name}"
class Address(models.Model):
    customer = models.ForeignKey(Customer, related_name='addresses', on_delete=models.CASCADE)
    address_line1 = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    postal_code = models.CharField(max_length=20)
    country = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.address_line1}, {self.city}, {self.state}"

from django.db import models
from django.contrib.auth.models import User

class Comment(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Comment by {self.user.username} on {self.item.name}"

class Reply(models.Model):
    comment = models.OneToOneField(Comment, on_delete=models.CASCADE, related_name='reply')
    user = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'is_staff': True})
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Reply by {self.user.username} on {self.comment}"


class PickupLocation(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField()
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pin = models.CharField(max_length=10)
    country = models.CharField(max_length=100, default="India")
    phone = models.CharField(max_length=15)

    def __str__(self):
        return f"{self.name} - {self.city}, {self.state}"

class ReturnDetails(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField()
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)
    pin = models.CharField(max_length=10)
    country = models.CharField(max_length=100, default="India")
    phone = models.CharField(max_length=15)

    def __str__(self):
        return f"{self.name} - {self.city}, {self.state}"

from django.db import models
from django.contrib.auth.models import User

class AdvertisementNew(models.Model):
    # Slideshow images
    slideshow1 = models.ImageField(upload_to='advertisements/slideshows/', null=True, blank=True)
    slideshow2 = models.ImageField(upload_to='advertisements/slideshows/', null=True, blank=True)
    slideshow3 = models.ImageField(upload_to='advertisements/slideshows/', null=True, blank=True)

    # Square box images
    box1 = models.ImageField(upload_to='advertisements/boxes/', null=True, blank=True)
    box2 = models.ImageField(upload_to='advertisements/boxes/', null=True, blank=True)
    box3 = models.ImageField(upload_to='advertisements/boxes/', null=True, blank=True)
    box4 = models.ImageField(upload_to='advertisements/boxes/', null=True, blank=True)
    box5 = models.ImageField(upload_to='advertisements/boxes/', null=True, blank=True)

    # Videos
    video1 = models.FileField(upload_to='advertisements/videos/', null=True, blank=True)
    video2 = models.FileField(upload_to='advertisements/videos/', null=True, blank=True)
    video3 = models.FileField(upload_to='advertisements/videos/', null=True, blank=True)
    video4 = models.FileField(upload_to='advertisements/videos/', null=True, blank=True)
    video5 = models.FileField(upload_to='advertisements/videos/', null=True, blank=True)
    video6 = models.FileField(upload_to='advertisements/videos/', null=True, blank=True)

    # Independent box images
    ibox1 = models.ImageField(upload_to='advertisements/independent_boxes/', null=True, blank=True)
    ibox2 = models.ImageField(upload_to='advertisements/independent_boxes/', null=True, blank=True)
    ibox3 = models.ImageField(upload_to='advertisements/independent_boxes/', null=True, blank=True)
    ibox4 = models.ImageField(upload_to='advertisements/independent_boxes/', null=True, blank=True)

    # Big image
    big1 = models.ImageField(upload_to='advertisements/big/', null=True, blank=True)

    # Associations with items
    item_slideshow1 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='slideshow1_ads')
    item_slideshow2 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='slideshow2_ads')
    item_slideshow3 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='slideshow3_ads')

    item_box1 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='box1_ads')
    item_box2 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='box2_ads')
    item_box3 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='box3_ads')
    item_box4 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='box4_ads')
    item_box5 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='box5_ads')

    item_video1 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='video1_ads')
    item_video2 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='video2_ads')
    item_video3 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='video3_ads')
    item_video4 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='video4_ads')
    item_video5 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='video5_ads')
    item_video6 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='video6_ads')

    item_ibox1 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='ibox1_ads')
    item_ibox2 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='ibox2_ads')
    item_ibox3 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='ibox3_ads')
    item_ibox4 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='ibox4_ads')

    item_big1 = models.ForeignKey('Item', on_delete=models.SET_NULL, null=True, blank=True, related_name='big1_ads')
    def save(self, *args, **kwargs):
        if AdvertisementNew.objects.exists() and not self.pk:
            raise ValidationError("Only one Advertisement instance is allowed.")
        super().save(*args, **kwargs)
    def __str__(self):
        return f"Advertisement {self.id}"

class OrderDashboard(models.Model):
    ORDER_TYPES = (
        ('prepaid', 'Prepaid'),
        ('postpaid', 'Postpaid'),
    )
    
    name = models.CharField(max_length=100)
    mobile_number = models.CharField(max_length=15)
    address = models.TextField()
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    order_datetime = models.DateTimeField(default=timezone.now)
    order_type = models.CharField(max_length=10, choices=ORDER_TYPES)
    pay_id = models.CharField(max_length=100, null=True, blank=True)
    pcode = models.IntegerField(null=True,blank=True)
    status = models.CharField(max_length=100,null=True, blank=True)

     # 👇 New field to attach the user who placed the order
    order_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='orders',null=True)
    

class OrderDashboardItem(models.Model):
    order = models.ForeignKey(OrderDashboard, related_name='items', on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    sku = models.CharField(max_length=50)
    quantity = models.PositiveIntegerField()
    
    
